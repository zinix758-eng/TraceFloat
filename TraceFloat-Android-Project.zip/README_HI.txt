TRACEFLOAT — Android floating drawing reference

IMPORTANT
- Yeh ek starter Android project hai, ready-made APK nahi.
- Is project ko Android build environment (Android Studio ya GitHub Actions) se APK mein build karna hoga.
- Y99 ke upar image reference dikhane ke liye Android 'Display over other apps' permission chahiye.
- Android security ke kaaran overlay opacity 80% se zyada nahi rakhi gayi hai. Kuch phones/Android versions par touch-through behavior alag ho sakta hai.
- Overlay image touch nahi leti; isliye finger gestures neeche Y99 tak pass hone chahiye.
- Overlay ko band karne ke liye notification mein Stop dabayein, ya app mein Stop floating image.

GitHub Actions build:
1. Is ZIP ko extract karke GitHub repository mein upload karein.
2. GitHub mein Actions tab kholein.
3. 'Build Android APK' workflow run karein.
4. Workflow complete hone par Artifacts se app-debug download karein.
5. APK phone mein install karein. Unknown-app install permission Android khud poochega.

Note: Yeh initial version hai. Agar phone par overlay permission, touch pass-through, ya Y99 compatibility mein issue aaye to error/screenshot bhejein; uske hisaab se code update karna hoga.
