package com.tracefloat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import java.io.InputStream;

public class OverlayService extends Service {
    public static final String ACTION_START = "com.tracefloat.START";
    public static final String ACTION_UPDATE = "com.tracefloat.UPDATE";
    private static final String CHANNEL = "tracefloat_overlay";
    private WindowManager wm;
    private ImageView imageView;
    private WindowManager.LayoutParams params;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if ("STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(intent.getAction()) || ACTION_UPDATE.equals(intent.getAction())) {
            startForeground(7, notification());
            showOrUpdate(intent);
        }
        return START_NOT_STICKY;
    }

    private void showOrUpdate(Intent intent) {
        try {
            String uriText = intent.getStringExtra("image");
            if (uriText == null) return;
            Uri uri = Uri.parse(uriText);
            InputStream in = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(in);
            if (in != null) in.close();
            if (bitmap == null) return;

            int opacity = intent.getIntExtra("opacity", 65);
            int size = intent.getIntExtra("size", 75);
            int x = intent.getIntExtra("x", 50);
            int y = intent.getIntExtra("y", 45);

            if (imageView == null) {
                imageView = new ImageView(this);
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imageView.setBackgroundColor(Color.TRANSPARENT);
                // NOT_TOUCHABLE lets drawing gestures pass through to Y99 underneath.
                int type = Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE;
                params = new WindowManager.LayoutParams(
                        Math.max(180, getResources().getDisplayMetrics().widthPixels * size / 100),
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                        PixelFormat.TRANSLUCENT);
                params.gravity = Gravity.TOP | Gravity.LEFT;
                wm.addView(imageView, params);
            }

            imageView.setImageBitmap(bitmap);
            // Keep overlay opacity below Android's common untrusted-touch blocking threshold.
            float overlayAlpha = Math.min(0.80f, Math.max(0.10f, opacity / 100f));
            imageView.setAlpha(overlayAlpha);
            params.alpha = overlayAlpha;
            params.width = Math.max(180, getResources().getDisplayMetrics().widthPixels * size / 100);
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            int maxX = Math.max(0, getResources().getDisplayMetrics().widthPixels - params.width);
            int maxY = Math.max(0, getResources().getDisplayMetrics().heightPixels - 300);
            params.x = maxX * x / 100;
            params.y = maxY * y / 100;
            wm.updateViewLayout(imageView, params);
        } catch (Exception e) {
            stopSelf();
        }
    }

    private Notification notification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        Intent stop = new Intent(this, OverlayService.class);
        stop.setAction("STOP");
        android.app.PendingIntent pi = android.app.PendingIntent.getService(
                this, 8, stop, android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
        return b.setContentTitle("TraceFloat is running")
                .setContentText("Drawing reference overlay is active. Tap Stop to close it.")
                .setSmallIcon(android.R.drawable.ic_menu_gallery)
                .addAction(android.R.drawable.ic_media_pause, "Stop", pi)
                .setOngoing(true).build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "TraceFloat overlay", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
\n
    @Override public void onDestroy() {
        if (imageView != null) {
            try { wm.removeView(imageView); } catch (Exception ignored) {}
            imageView = null;
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
