package com.tracefloat.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 101;
    private Uri selectedImage;
    private boolean overlayStarted = false;
    private int opacity = 65, size = 75, xPos = 50, yPos = 45;
    private TextView imageStatus;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        buildUi();
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 30, 28, 24);
        page.setBackgroundColor(0xFF101820);

        TextView title = new TextView(this);
        title.setText("TraceFloat");
        title.setTextSize(30);
        title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Floating drawing reference for Y99");
        subtitle.setTextColor(0xFFB9C7D3);
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle);

        Button choose = button("1. Choose drawing photo");
        page.addView(choose);
        choose.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, PICK_IMAGE);
        });

        imageStatus = new TextView(this);
        imageStatus.setText("No image selected");
        imageStatus.setTextColor(0xFFFFFFFF);
        imageStatus.setPadding(0, 12, 0, 12);
        page.addView(imageStatus);

        addSlider(page, "Transparency (lower = more see-through)", 10, 80, opacity, value -> opacity = value);
        addSlider(page, "Image size", 25, 100, size, value -> size = value);
        addSlider(page, "Horizontal position", 0, 100, xPos, value -> xPos = value);
        addSlider(page, "Vertical position", 0, 100, yPos, value -> yPos = value);

        Button start = button("2. Start floating image");
        page.addView(start);
        start.setOnClickListener(v -> startOverlay());

        Button stop = button("Stop floating image");
        page.addView(stop);
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            overlayStarted = false;
        });

        TextView note = new TextView(this);
        note.setText("How to use: select a photo → allow overlay permission → start floating image → open Y99 drawing. The reference image does not receive touch, so your finger can draw in Y99 underneath.");
        note.setTextColor(0xFFB9C7D3);
        note.setTextSize(13);
        note.setPadding(2, 18, 2, 0);
        page.addView(note);

        setContentView(page);
    }

    private interface Change { void set(int value); }

    private void addSlider(LinearLayout page, String label, int min, int max, int initial, Change change) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(0xFFFFFFFF);
        t.setPadding(0, 10, 0, 2);
        page.addView(t);
        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(initial - min);
        page.addView(bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                change.set(p + min);
                updateIfRunning();
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        return b;
    }

    private void startOverlay() {
        if (selectedImage == null) {
            Toast.makeText(this, "Pehle drawing photo select karein", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(permission);
            Toast.makeText(this, "TraceFloat ko 'Display over other apps' permission dein, phir wapas aakar Start dabayein.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent service = new Intent(this, OverlayService.class);
        service.setAction(OverlayService.ACTION_START);
        service.putExtra("image", selectedImage.toString());
        addSettings(service);
        startService(service);
        overlayStarted = true;
        Toast.makeText(this, "Floating image started. Ab Y99 open karein.", Toast.LENGTH_LONG).show();
    }

    private void updateIfRunning() {
        if (!overlayStarted || selectedImage == null || !Settings.canDrawOverlays(this)) return;
        Intent i = new Intent(this, OverlayService.class);
        i.setAction(OverlayService.ACTION_UPDATE);
        i.putExtra("image", selectedImage.toString());
        addSettings(i);
        startService(i);
    }

    private void addSettings(Intent i) {
        i.putExtra("opacity", opacity);
        i.putExtra("size", size);
        i.putExtra("x", xPos);
        i.putExtra("y", yPos);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            selectedImage = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(selectedImage,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            imageStatus.setText("Selected: " + selectedImage.getLastPathSegment());
        }
    }
}
